@echo off
setlocal enabledelayedexpansion
title Forge IDE Installer

:: ── Find Node.js EVERYWHERE ──────────────────────────────────────────────────
echo.
echo ===================================================
echo            Forge IDE Installer
echo ===================================================
echo.

echo [1/4] Finding Node.js...

set "NODE_OK=0"

:: Check PATH first
where node >nul 2>&1 && set "NODE_OK=1" && goto :node_found

:: Check common install locations
for %%p in (
    "C:\Program Files\nodejs\node.exe"
    "C:\Program Files (x86)\nodejs\node.exe"
    "%LOCALAPPDATA%\Programs\nodejs\node.exe"
    "%APPDATA%\nvm\node.exe"
    "%APPDATA%\fnm\node.exe"
    "C:\nvm\node.exe"
    "C:\fnm\node.exe"
    "%USERPROFILE%\.nvm\node.exe"
    "%USERPROFILE%\.fnm\node.exe"
    "%PROGRAMFILES%\nvm\node.exe"
    "%PROGRAMFILES%\fnm\node.exe"
) do (
    if exist %%p (
        set "NODE_DIR=%%~dpp"
        set "PATH=!NODE_DIR!;!PATH!"
        set "NODE_OK=1"
        goto :node_found
    )
)

:: Search all drives for node.exe
echo   Searching all drives...
for %%d in (C D E F G H) do (
    if exist "%%d:\" (
        for /f "tokens=*" %%n in ('dir /s /b "%%d:\node.exe" 2^>nul') do (
            if not "!NODE_OK!"=="1" (
                set "NODE_DIR=%%~dpn"
                set "PATH=!NODE_DIR!;!PATH!"
                set "NODE_OK=1"
                goto :node_found
            )
        )
    )
)

:: Not found - download it
echo   Node.js not found anywhere.
echo   Downloading Node.js v20...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$u='https://nodejs.org/dist/v20.18.0/node-v20.18.0-x64.msi';" ^
  "$o='%TEMP%\node-install.msi';" ^
  "Write-Host '  Downloading...';" ^
  "(New-Object Net.WebClient).DownloadFile($u,$o);" ^
  "Write-Host '  Installing (silent, may take a minute)...';" ^
  "Start-Process msiexec.exe -ArgumentList '/i',$o,'/qn' -Wait;" ^
  "Write-Host '  Done.'"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo   FAILED. Install Node.js manually from https://nodejs.org
    pause
    exit /b 1
)
set "PATH=C:\Program Files\nodejs;!PATH!"

:node_found
for /f "tokens=*" %%v in ('node --version 2^>nul') do echo   Node.js %%v
echo.

:: ── Find the package ────────────────────────────────────────────────────────
echo [2/4] Finding Forge IDE package...

:: Look in same folder as this .bat
set "TGZ=%~dp0installer\forge-ide-1.0.0.tgz"
if exist "!TGZ!" goto :tgz_found
set "TGZ=%~dp0forge-ide-1.0.0.tgz"
if exist "!TGZ!" goto :tgz_found
set "TGZ=%~dp0forge-ide\installer\forge-ide-1.0.0.tgz"
if exist "!TGZ!" goto :tgz_found

:: Search for it
echo   Searching for package...
for %%d in (C D E F G H) do (
    for /f "tokens=*" %%f in ('dir /s /b "%%d:\forge-ide-1.0.0.tgz" 2^>nul') do (
        if not defined TGZ (
            set "TGZ=%%f"
            goto :tgz_found
        )
    )
)

:: No .tgz found - check if forge-ide folder exists with package.json
echo   No .tgz found. Looking for source folder...
for %%d in (C D E F G H) do (
    for /f "tokens=*" %%f in ('dir /s /b "%%d:\package.json" 2^>nul') do (
        findstr /c:"forge-ide" "%%f" >nul 2>&1
        if !errorlevel! equ 0 (
            set "SRC_DIR=%%~dpf"
            goto :src_found
        )
    )
)

echo   ERROR: Could not find Forge IDE package.
echo   Make sure the installer folder contains forge-ide-1.0.0.tgz
pause
exit /b 1

:tgz_found
echo   Found: !TGZ!
echo.

:: ── Install ─────────────────────────────────────────────────────────────────
echo [3/4] Installing Forge IDE...

call npm install -g "!TGZ!"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo   Installation failed. Retrying...
    call npm install -g "!TGZ!"
    if %ERRORLEVEL% NEQ 0 (
        echo   FAILED. Try running as Administrator.
        pause
        exit /b 1
    )
)
echo   Installed.
goto :installed

:src_found
echo   Found source at: !SRC_DIR!
echo.
echo [3/4] Installing Forge IDE...
call npm install -g "!SRC_DIR!"
if %ERRORLEVEL% NEQ 0 (
    echo   FAILED.
    pause
    exit /b 1
)
echo   Installed.

:installed
echo.

:: ── Find install path ───────────────────────────────────────────────────────
for /f "tokens=*" %%i in ('npm config get prefix 2^>nul') do set "NPM_PREFIX=%%i"
set "FORGE_PATH=!NPM_PREFIX!\node_modules\forge-ide"
if not exist "!FORGE_PATH!\src\index.js" (
    set "FORGE_PATH=!NPM_PREFIX!\node_modules\@omar-azam\forge-agent"
)

:: ── Install browser engine ──────────────────────────────────────────────────
echo [4/4] Installing Chromium browser...

if exist "!FORGE_PATH!\node_modules\playwright" (
    echo   Playwright found.
) else (
    echo   Installing dependencies...
    call npm install --prefix "!FORGE_PATH!" >nul 2>&1
)

call npx --prefix "!FORGE_PATH!" playwright install chromium >nul 2>&1
echo   Done.
echo.

:: ── Create launcher + shortcuts ─────────────────────────────────────────────
echo Setting up shortcuts...

set "FORGE_CMD=!NPM_PREFIX!\forge-ide.cmd"
if not exist "!FORGE_CMD!" (
    >"!FORGE_CMD!" (
        echo @echo off
        echo setlocal
        echo set "FORGE_DIR=!FORGE_PATH!"
        echo cd /d "%%FORGE_DIR%%"
        echo node src/index.js --ide %%*
    )
)

set "ICON_DIR=%APPDATA%\Forge IDE"
if not exist "!ICON_DIR!" mkdir "!ICON_DIR!"
set "ICON_FILE=!ICON_DIR!\forge-icon.ico"
set "SRC_ICON=!FORGE_PATH!\installer\forge-icon.ico"
if exist "!SRC_ICON!" copy /Y "!SRC_ICON!" "!ICON_FILE!" >nul 2>&1

set "SM_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Forge IDE"
if not exist "!SM_DIR!" mkdir "!SM_DIR!"

>"%TEMP%\forge-shortcut.vbs" (
    echo Set s = CreateObject^("WScript.Shell"^)
    echo Set d = s.CreateShortcut^(s.SpecialFolders^("Desktop"^) ^& "\Forge IDE.lnk"^)
    echo d.TargetPath = "!FORGE_CMD!"
    echo d.WorkingDirectory = "!FORGE_PATH!"
    echo d.Description = "Forge IDE"
    echo d.IconLocation = "!ICON_FILE!,0"
    echo d.Save
    echo Set m = s.CreateShortcut^("!SM_DIR!\Forge IDE.lnk"^)
    echo m.TargetPath = "!FORGE_CMD!"
    echo m.WorkingDirectory = "!FORGE_PATH!"
    echo m.Description = "Forge IDE"
    echo m.IconLocation = "!ICON_FILE!,0"
    echo m.Save
)
cscript //nologo "%TEMP%\forge-shortcut.vbs" >nul 2>&1
del "%TEMP%\forge-shortcut.vbs" >nul 2>&1

echo.
echo ===================================================
echo          Installation Complete!
echo ===================================================
echo.
echo   Launch from:
echo     Desktop:    "Forge IDE"
echo     Start Menu: Programs ^> Forge IDE
echo     Terminal:   forge-ide
echo.
echo ===================================================
echo.
pause
