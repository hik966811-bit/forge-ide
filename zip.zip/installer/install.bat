@echo off
setlocal enabledelayedexpansion
title Forge IDE Installer

echo.
echo ===================================================
echo            Forge IDE Installer
echo ===================================================
echo.

:: ── Step 1: Node.js ──────────────────────────────────────────────────────────
echo [1/3] Checking Node.js...

set "NODE_OK=0"
where node >nul 2>&1 && set "NODE_OK=1"
if "!NODE_OK!"=="1" goto :node_found

for %%p in (
    "C:\Program Files\nodejs\node.exe"
    "C:\Program Files (x86)\nodejs\node.exe"
    "%LOCALAPPDATA%\Programs\nodejs\node.exe"
) do (
    if exist %%p (
        set "PATH=%%~dpp;!PATH!"
        set "NODE_OK=1"
        goto :node_found
    )
)

echo   Node.js not found. Downloading...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$u='https://nodejs.org/dist/v20.18.0/node-v20.18.0-x64.msi';" ^
  "$o='%TEMP%\node-install.msi';" ^
  "Write-Host '  Downloading...';" ^
  "(New-Object Net.WebClient).DownloadFile($u,$o);" ^
  "Write-Host '  Installing...';" ^
  "Start-Process msiexec.exe -ArgumentList '/i',$o,'/qn' -Wait"
set "PATH=C:\Program Files\nodejs;!PATH%"

:node_found
for /f "tokens=*" %%v in ('node --version 2^>nul') do echo   Node.js %%v
echo.

:: ── Step 2: Install ─────────────────────────────────────────────────────────
echo [2/3] Installing Forge IDE...

:: Find the .tgz
set "TGZ="
for %%f in ("%~dp0forge-ide-1.0.0.tgz" "%~dp0installer\forge-ide-1.0.0.tgz" "%~dp0..\forge-ide-1.0.0.tgz" "%~dp0..\installer\forge-ide-1.0.0.tgz") do (
    if exist %%f if not defined TGZ set "TGZ=%%~ff"
)

if defined TGZ (
    call npm install -g "!TGZ!"
) else (
    call npm install -g forge-ide
)
if %ERRORLEVEL% NEQ 0 (
    echo   FAILED. Try running as Administrator.
    pause
    exit /b 1
)
echo   Done.
echo.

:: ── Step 3: Browser ─────────────────────────────────────────────────────────
echo [3/3] Installing Chromium browser...

for /f "tokens=*" %%i in ('npm root -g 2^>nul') do set "NPM_ROOT=%%i"
set "PKG=!NPM_ROOT!\forge-ide"
if not exist "!PKG!\src\index.js" set "PKG=!NPM_ROOT!\@omar-azam\forge-agent"

call npx --prefix "!PKG!" playwright install chromium >nul 2>&1
echo   Done.
echo.

:: ── Shortcuts ───────────────────────────────────────────────────────────────
for /f "tokens=*" %%i in ('npm config get prefix 2^>nul') do set "NPM_PREFIX=%%i"
set "CMD=%NPM_PREFIX%\forge-ide.cmd"
if not exist "!CMD!" (
    >"!CMD!" (
        echo @echo off
        echo cd /d "!PKG!"
        echo node src/index.js --ide %%*
    )
)

set "ICO=%APPDATA%\Forge IDE"
if not exist "!ICO!" mkdir "!ICO!"
if exist "!PKG!\installer\forge-icon.ico" copy /Y "!PKG!\installer\forge-icon.ico" "!ICO!\forge-icon.ico" >nul 2>&1

>"%TEMP%\vbs.vbs" (
    echo Set s=CreateObject^("WScript.Shell"^)
    echo Set d=s.CreateShortcut^(s.SpecialFolders^("Desktop"^)^&"\Forge IDE.lnk"^)
    echo d.TargetPath="!CMD!"
    echo d.WorkingDirectory="!PKG!"
    echo d.IconLocation="!ICO!\forge-icon.ico,0"
    echo d.Save
)
cscript //nologo "%TEMP%\vbs.vbs" >nul 2>&1
del "%TEMP%\vbs.vbs" >nul 2>&1

echo ===================================================
echo          Installation Complete!
echo ===================================================
echo.
echo   Launch: Desktop shortcut or "forge-ide"
echo.
pause
